"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.textareaNotes = void 0;
exports.textareaNotes = document.getElementById("textarea");

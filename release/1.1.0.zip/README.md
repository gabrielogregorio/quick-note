# Quick Note

Está é a minha primeira extensão, e o foco dela é ser simples
